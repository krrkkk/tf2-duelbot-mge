english · [русский](README.ru.md)

# mgebot duel 5.1.2

MGE bot duels for TF2. by avxgroup.

## install

1. install official SourceMod and MetaMod for your system.
2. merge this package's `tf` folder into your game/server. keep your configs and databases.
3. for a local game, restart TF2 with `-insecure -console`.
4. run `map mge_triumph_beta7_rc1`, then `exec botduel-local`.
5. type `!add`, pick an arena and start. `!settings` opens bot settings.

with the launcher, just press **install** — it handles the files for you.
the update-only ZIP needs the map already installed.

## 5.1.2

- no extra plugin hit sound.
- app connection no longer prints status into the game console.
- direct app startup without the arena menu or waiting-for-players timer.
- the bot waits 5 seconds in the first app-started duel only.

## 5.1.1

- losing a ranged damage trade now triggers a sustained push for every class.
- the bot keeps chasing instead of returning to its old high ground.
- Soldier can rocket-jump to close the gap when the route and HP allow it.
- the launcher shows the bot's current plan and learning updates.
- a local companion plugin connects the launcher without TCP RCON.

learning is shared by bots on the same installation. history and arena edits stay on your computer.

[installation](INSTALL-EN.txt) · [editor and sharing routes](EDITOR-EN.txt) · [linux loader](LINUX-LISTEN-EN.txt) · [changes](CHANGES-EN.txt)
